package sintakskomentar;

//setiap kode yang berjalan di java harus berada dalam class (ini adalah komentar)
//setiap class haru berawalkan huruf besar
//nama file java harus sama dengan nama class
public class SintaksKomentar {

    //main method diperlukan untuk mengeksekusi setiap kode java didalamnya
    public static void main(String[] args) {
        //didalam main method bisa menggunakan println methode untuk mencetak satu baris teks ke layar
        System.out.println("Hello World My Name Is Muhammad Fazron Arif");
    }
    
}
